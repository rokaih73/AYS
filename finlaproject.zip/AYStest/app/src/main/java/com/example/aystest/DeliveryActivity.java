package com.example.aystest;


import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class DeliveryActivity extends AppCompatActivity {


    TextView info;
    EditText chooseTime;
    TimePickerDialog MYTIME;
    Calendar ce;
    int chour;
    int cmin;
    Button show;
    String ampm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery);

        info=(TextView)findViewById(R.id.info);

        chooseTime=(EditText)findViewById(R.id.ctime);
        chooseTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String p = MYTIME+"";
                ce= Calendar.getInstance();
                chour=ce.get(Calendar.HOUR_OF_DAY);
                cmin=ce.get(Calendar.MINUTE);
                MYTIME = new TimePickerDialog(DeliveryActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        if(hourOfDay>=12){
                            ampm="PM";
                        }else {
                            ampm="AM";
                        }
                        // chooseTime.setText(hourOfDay+ ":"+ minute+ampm);
                        chooseTime.setText(String.format("%02d:%02d",hourOfDay,minute)+ampm);

                    }
                },chour,cmin, false);

                MYTIME.show();




            }
        });


        show=(Button)findViewById(R.id.m11);

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu mb = new PopupMenu(DeliveryActivity.this,show);
                mb.getMenuInflater().inflate(R.menu.popup_menu,mb.getMenu());
                mb.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        Toast.makeText(DeliveryActivity.this, " "+item.getTitle(),Toast.LENGTH_LONG).show();
                        return true;
                    }
                });

                mb.show();





            }
        });






    }



}