package com.example.aystest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class secActivity extends AppCompatActivity {


    private String coffeeType1="";
    private String coffeeType2="";
    private String coffeeType3="";
    private String coffeeType4="";
    private String coffeeType5="";
    private String coffeeType6="";
    private String coffeeType7="";
    private String coffeeType8="";
    private String coffeeType9="";
    private String coffeeType10="";

    private String sweetType1="";
    private String sweetType2="";
    private String sweetType3="";
    private String sweetType4="";

    private Button mkOrder;

    int TotPrice1=0;
    int TotPrice2=0;
    int TotPrice3=0;
    int TotPrice4=0;
    int TotPrice5=0;
    int TotPrice6=0;
    int TotPrice7=0;
    int TotPrice8=0;
    int TotPrice9=0;
    int TotPrice10=0;
    int TotPrice11=0;
    int TotPrice12=0;
    int TotPrice13=0;
    int TotPrice14=0;

    int i;


    private int numCofe1 = 1;
    private int numCofe2 = 1;
    private int numCofe3 = 1;
    private int numCofe4 = 1;
    private int numCofe5 = 1;
    private int numCofe6 = 1;
    private int numCofe7 = 1;
    private int numCofe8 = 1;
    private int numCofe9 = 1;
    private int numCofe10 = 1;
    private int numSwet1 = 1;
    private int numSwet2 = 1;
    private int numSwet3 = 1;
    private int numSWet4 = 1;

    TextView tx1;
    TextView tx2;
    TextView tx3;
    TextView tx4;
    TextView tx5;
    TextView tx6;
    TextView tx7;
    TextView tx8;
    TextView tx9;
    TextView tx10;
    TextView tx11;
    TextView tx12;
    TextView tx13;
    TextView tx14;


    TextView txtv1;
    TextView txtv2;
    TextView txtv3;
    TextView txtv4;
    TextView txtv5;
    TextView txtv6;
    TextView txtv7;
    TextView txtv8;
    TextView txtv9;
    TextView txtv10;
    TextView txtv11;
    TextView txtv12;
    TextView txtv13;
    TextView txtv14;

    CheckBox cb1;
    CheckBox cb2;
    CheckBox cb3;
    CheckBox cb4;
    CheckBox cb5;
    CheckBox cb6;
    CheckBox cb7;
    CheckBox cb8;
    CheckBox cb9;
    CheckBox cb10;
    CheckBox cb11;
    CheckBox cb12;
    CheckBox cb13;
    CheckBox cb14;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);

        mkOrder = (Button) findViewById(R.id.button2);

        tx1 = (TextView) findViewById(R.id.carMacciatoP);
        tx2 = (TextView) findViewById(R.id.amrcP);
        tx3 = (TextView) findViewById(R.id.mochaP);
        tx4 = (TextView) findViewById(R.id.latteP);
        tx5 = (TextView) findViewById(R.id.esprsoP);
        tx6 = (TextView) findViewById(R.id.CappuccinoP);
        tx7 = (TextView) findViewById(R.id.frenchP);
        tx8 = (TextView) findViewById(R.id.chocoMochaP);
        tx9 = (TextView) findViewById(R.id.spanishP);
        tx10 = (TextView) findViewById(R.id.icedCrmlMacchiatoP);
        tx11 = (TextView) findViewById(R.id.BrowniesP);
        tx12 = (TextView) findViewById(R.id.MacaroonsP);
        tx13 = (TextView) findViewById(R.id.CookiesP);
        tx14 = (TextView) findViewById(R.id.CupcakesP);

        txtv1 = (TextView) findViewById(R.id.counter1);
        txtv2 = (TextView) findViewById(R.id.counter2);
        txtv3 = (TextView) findViewById(R.id.counter3);
        txtv4 = (TextView) findViewById(R.id.counter4);
        txtv5 = (TextView) findViewById(R.id.counter5);
        txtv6 = (TextView) findViewById(R.id.counter6);
        txtv7 = (TextView) findViewById(R.id.counter7);
        txtv8 = (TextView) findViewById(R.id.counter8);
        txtv9 = (TextView) findViewById(R.id.counter9);
        txtv10 = (TextView) findViewById(R.id.counter10);
        txtv11 = (TextView) findViewById(R.id.counter11);
        txtv12 = (TextView) findViewById(R.id.counter12);
        txtv13 = (TextView) findViewById(R.id.counter13);
        txtv14 = (TextView) findViewById(R.id.counter14);

        cb1= (CheckBox) findViewById(R.id.crmlMachiatoBtn);
        cb2= (CheckBox) findViewById(R.id.amrcanoBtn);
        cb3= (CheckBox) findViewById(R.id.mochaBtn);
        cb4= (CheckBox) findViewById(R.id.latteBtn);
        cb5= (CheckBox) findViewById(R.id.esprsoBtn);
        cb6= (CheckBox) findViewById(R.id.CappuccinoBtn);
        cb7= (CheckBox) findViewById(R.id.frenchBtn);
        cb8= (CheckBox) findViewById(R.id.chocoMochaBtn);
        cb9= (CheckBox) findViewById(R.id.spanishBtn);
        cb10=(CheckBox) findViewById(R.id.icedCrmlMacchiatoBtn);
        cb11=(CheckBox) findViewById(R.id.browniBtn);
        cb12=(CheckBox) findViewById(R.id.MacaroonsBtn);
        cb13=(CheckBox) findViewById(R.id.CookiesBtn);
        cb14=(CheckBox) findViewById(R.id.CupcakesBtn);


        mkOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String order = coffeeType1 + coffeeType2 + coffeeType3 +coffeeType4
                        + coffeeType5 + coffeeType6 + coffeeType7 + coffeeType8
                        + coffeeType9 + coffeeType10 + sweetType1 + sweetType2
                        + sweetType3 + sweetType4 ;

                int sum = TotPrice1+TotPrice2+TotPrice3+TotPrice4+TotPrice5+TotPrice6+TotPrice7+
                        TotPrice8+TotPrice9+TotPrice10+TotPrice11+TotPrice12+TotPrice13;

                if(order.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Please Choose An Order To Continue "
                            ,Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent i = new Intent(secActivity.this, AddToDatabase.class);

                i.putExtra( "order", order);

                i.putExtra( "price", sum );

                startActivity(i);
                finish();

            }

        });
    }

    public void selectCoffee(View view) {

        switch (view.getId()) {
            case R.id.crmlMachiatoBtn:
                if(cb1.isChecked()){
                    coffeeType1 = "Hot Caramel Macchiato \n";
                    TotPrice1=10;
                    break;}
                else {coffeeType1="";
                    TotPrice1=0;}

            case R.id.amrcanoBtn:
                if(cb2.isChecked()){
                    coffeeType2 = "Hot Amricano \n";
                    TotPrice2=8;
                    break;}
                else {coffeeType2="";
                    TotPrice2=0;}

            case R.id.mochaBtn:
                if(cb3.isChecked()){
                    coffeeType3 = "Hot Mocha \n";
                    TotPrice3=12;
                    break;}
                else {coffeeType3="";
                    TotPrice3=0;}

            case R.id.latteBtn:
                if(cb4.isChecked()){
                    coffeeType4 = "Hot Latte \n";
                    TotPrice4=10;
                    break;}
                else {coffeeType4="";
                    TotPrice4=0;}

            case R.id.esprsoBtn:
                if(cb5.isChecked()){
                    coffeeType5 = "Hot Espresso \n";
                    TotPrice5=7;
                    break;}
                else {coffeeType5="";
                    TotPrice5=0;}

            case R.id.CappuccinoBtn:
                if(cb6.isChecked()){
                    coffeeType6 = "Hot Cappuccino \n";
                    TotPrice6=12;
                    break;}
                else{ coffeeType6="";
                    TotPrice6=0;}

            case R.id.frenchBtn:
                if(cb7.isChecked()){
                    coffeeType7 = "Iced French Vanilla \n";
                    TotPrice7=12;
                    break;}
                else {coffeeType7="";
                    TotPrice7=0;}

            case R.id.chocoMochaBtn:
                if(cb8.isChecked()){
                    coffeeType8 = "Iced Chocolate Mohca \n";
                    TotPrice8=10;
                    break;}
                else {coffeeType8="";
                    TotPrice8=0;}

            case R.id.spanishBtn:
                if(cb9.isChecked()){
                    coffeeType9 = "Iced Spanish Latte \n";
                    TotPrice9=10;
                    break;}
                else {coffeeType9="";
                    TotPrice9=0;}

            case R.id.icedCrmlMacchiatoBtn:
                if(cb10.isChecked()) {
                    coffeeType10 = "Iced Caramel Macchiato \n";
                    TotPrice10=14;
                }
                else {coffeeType10="";
                    TotPrice10=0;}


        }
    }

    public void selectSweets(View v) {

        switch (v.getId()) {
            case R.id.browniBtn:
                if(cb11.isChecked()){
                    sweetType1 = "Brownies \n";
                    TotPrice11=5;
                    break;}
                else  {sweetType1="";
                    TotPrice11=0;}

            case R.id.MacaroonsBtn:
                if(cb12.isChecked()){
                    sweetType2 = "Macaroons \n";
                    TotPrice12=6;
                    break;}
                else  {sweetType2="";
                    TotPrice12=0;}

            case R.id.CookiesBtn:
                if(cb13.isChecked()){
                    sweetType3 = "Cookies \n";
                    TotPrice13=4;
                    break;}
                else { sweetType3="";
                    TotPrice13=0;}

            case R.id.CupcakesBtn:
                if(cb14.isChecked()) {
                    sweetType4 = "Cupcakes \n";
                    TotPrice14=4;
                } else { sweetType4="";
                    TotPrice14=0;}
        }
    }

    public void increment(View v) {

        String msg = "Choose The Coffee To Increase The Quantity";
        String msg2 = "Choose The Sweet To Increase The Quantity";

        switch (v.getId()) {
            case R.id.incBtn1:
                if(coffeeType1.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}

                numCofe1 += 1;
                i = numCofe1*10;
                TotPrice1=i;
                tx1.setText("  " +i +" SR");
                txtv1.setText(" " + numCofe1);
                break;

            case R.id.incBtn2:
                if(coffeeType2.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe2 += 1;
                i = numCofe2*8;
                TotPrice2=i;
                tx2.setText("  " +i +" SR");
                txtv2.setText(" " + numCofe2);
                break;

            case R.id.incBtn3:
                if(coffeeType3.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe3 += 1;
                i = numCofe3*12;
                TotPrice3=i;
                tx3.setText("  " +i +" SR");
                txtv3.setText(" " + numCofe3);
                break;

            case R.id.incBtn4:
                if(coffeeType4.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe4 += 1;
                i = numCofe4*10;
                TotPrice4=i;
                tx4.setText("  " +i +" SR");
                txtv4.setText(" " + numCofe4);
                break;

            case R.id.incBtn5:
                if(coffeeType5.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe5 += 1;
                i = numCofe5*7;
                TotPrice5=i;
                tx5.setText("  " +i +" SR");
                txtv5.setText(" " + numCofe5);
                break;

            case R.id.incBtn6:
                if(coffeeType6.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe6 += 1;
                i = numCofe6*12;
                TotPrice6=i;
                tx6.setText("  " +i +" SR");
                txtv6.setText(" " + numCofe6);
                break;

            case R.id.incBtn7:
                if(coffeeType7.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe7 += 1;
                i = numCofe7*12;
                TotPrice7=i;
                tx7.setText("  " +i +" SR");
                txtv7.setText(" " + numCofe7);
                break;

            case R.id.incBtn8:
                if(coffeeType8.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe8 += 1;
                i = numCofe8*10;
                TotPrice8=i;
                tx8.setText("  " +i +" SR");
                txtv8.setText(" " + numCofe8);
                break;

            case R.id.incBtn9:
                if(coffeeType9.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe9 += 1;
                i = numCofe9*10;
                TotPrice9=i;
                tx9.setText("  " +i +" SR");
                txtv9.setText(" " + numCofe9);
                break;

            case R.id.incBtn10:
                if(coffeeType10.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    return;}
                numCofe10 += 1;
                i = numCofe10*14;
                TotPrice10=i;
                tx10.setText("  " +i +" SR");
                txtv10.setText(" " + numCofe10);
                break;

            case R.id.incBtn11:
                if(sweetType1.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                    return;}
                numSwet1 += 1;
                i = numSwet1*5;
                TotPrice11=i;
                tx11.setText("  " +i +" SR");
                txtv11.setText(" " + numSwet1);
                break;

            case R.id.incBtn12:
                if(sweetType2.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                    return;}
                numSwet2 += 1;
                i = numSwet2*6;
                TotPrice12=i;
                tx12.setText("  " +i +" SR");
                txtv12.setText(" " + numSwet2);
                break;

            case R.id.incBtn13:
                if(sweetType3.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                    return;}
                numSwet3 += 1;
                i = numSwet3*4;
                TotPrice13=i;
                tx13.setText("  " +i +" SR");
                txtv13.setText(" " + numSwet3);
                break;

            case R.id.incBtn14:
                if(sweetType4.isEmpty()) {
                    Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                    return;}
                numSWet4 += 1;
                i = numSWet4*4;
                TotPrice14=i;
                tx14.setText("  " +i +" SR");
                txtv14.setText(" " + numSWet4);

        }
    }

    public void decrement(View v) {

        String msg = "Choose The Coffee To Decrease The Quantity";
        String msg2 = "Choose The Sweet To Decrease The Quantity";

        if(v.getId()==R.id.decBtn1){
            if(coffeeType1.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe1 > 1) {
                numCofe1 -= 1;
                i = numCofe1*10;
                TotPrice1=i;
                tx1.setText("  " +i +" SR");
                txtv1.setText(" " + numCofe1);

            }  else{
                txtv1.setText(" " + numCofe1);
            }}

        if (v.getId()==R.id.decBtn2){
            if(coffeeType2.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe2 > 1) {
                numCofe2 -= 1;
                i = numCofe2*8;
                TotPrice2=i;
                tx2.setText("  " +i +" SR");
                txtv2.setText(" " + numCofe2);

            }  else{
                txtv2.setText(" " + numCofe2);
            }}

        if (v.getId()==R.id.decBtn3){
            if(coffeeType3.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe3 > 1) {
                numCofe3 -= 1;
                i = numCofe3*12;
                TotPrice3=i;
                tx3.setText("  " +i +" SR");
                txtv3.setText(" " + numCofe3);

            }  else{
                txtv3.setText(" " + numCofe3);
            }}

        if (v.getId()==R.id.decBtn4){
            if(coffeeType4.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe4 > 1) {
                numCofe4 -= 1;
                i = numCofe4*10;
                TotPrice4=i;
                tx4.setText("  " +i +" SR");
                txtv4.setText(" " + numCofe4);

            }  else{
                txtv4.setText(" " + numCofe4);
            }}

        if (v.getId()==R.id.decBtn5){
            if(coffeeType5.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe5 > 1) {
                numCofe5 -= 1;
                i = numCofe5*7;
                TotPrice5=i;
                tx5.setText("  " +i +" SR");
                txtv5.setText(" " + numCofe5);

            }  else{
                txtv5.setText(" " + numCofe5);
            }}

        if (v.getId()==R.id.decBtn6){
            if(coffeeType6.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe6 > 1) {
                numCofe6 -= 1;
                i = numCofe6*12;
                TotPrice6=i;
                tx6.setText("  " +i +" SR");
                txtv6.setText(" " + numCofe6);

            }  else{
                txtv6.setText(" " + numCofe6);
            }}

        if (v.getId()==R.id.decBtn7){
            if(coffeeType7.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe7 > 1) {
                numCofe7 -= 1;
                i = numCofe7*12;
                TotPrice7=i;
                tx7.setText("  " +i +" SR");
                txtv7.setText(" " + numCofe7);

            }  else{
                txtv7.setText(" " + numCofe7);
            }}

        if (v.getId()==R.id.decBtn8){
            if(coffeeType8.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe8 > 1) {
                numCofe8 -= 1;
                i = numCofe8*10;
                TotPrice8=i;
                tx8.setText("  " +i +" SR");
                txtv8.setText(" " + numCofe8);

            }  else{
                txtv8.setText(" " + numCofe8);
            }}

        if (v.getId()==R.id.decBtn9){
            if(coffeeType9.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe9 > 1) {
                numCofe9 -= 1;
                i = numCofe9*10;
                TotPrice9=i;
                tx9.setText("  " +i +" SR");
                txtv9.setText(" " + numCofe9);

            }  else{
                txtv9.setText(" " + numCofe9);
            }}

        if (v.getId()==R.id.decBtn10){
            if(coffeeType10.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                return;}

            if (numCofe10 > 1) {
                numCofe10 -= 1;
                i = numCofe10*14;
                TotPrice10=i;
                tx10.setText("  " +i +" SR");
                txtv10.setText(" " + numCofe10);

            }  else{
                txtv10.setText(" " + numCofe10);
            }}

        if (v.getId()==R.id.decBtn11){
            if(sweetType1.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                return;}

            if (numSwet1 > 1) {
                numSwet1 -= 1;
                i = numSwet1*5;
                TotPrice11=i;
                tx11.setText("  " +i +" SR");
                txtv11.setText(" " + numSwet1);

            }  else{
                txtv11.setText(" " + numSwet1);
            }}
        if (v.getId()==R.id.decBtn12){
            if(sweetType2.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                return;}

            if (numSwet2 > 1) {
                numSwet2 -= 1;
                i = numSwet2*6;
                TotPrice12=i;
                tx12.setText("  " +i +" SR");
                txtv12.setText(" " + numSwet2);

            }  else{
                txtv12.setText(" " + numSwet2);
            }}

        if (v.getId()==R.id.decBtn13){
            if(sweetType3.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                return;}

            if (numSwet3 > 1) {
                numSwet3 -= 1;
                i = numSwet3*4;
                TotPrice13=i;
                tx13.setText("  " +i +" SR");
                txtv13.setText(" " + numSwet3);

            }  else{
                txtv13.setText(" " + numSwet3);
            }}

        if (v.getId()==R.id.decBtn14){
            if(sweetType4.isEmpty()) {
                Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
                return;}

            if (numSWet4 > 1) {
                numSWet4 -= 1;
                i = numSWet4*4;
                TotPrice14=i;
                tx14.setText("  " +i +" SR");
                txtv14.setText(" " + numSWet4);

            }  else{
                txtv14.setText(" " + numSWet4);
            }}

    }

    public void back(View v){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    public void clearAllButtonHandler(View v) {

        cb1.setChecked(false);
        cb2.setChecked(false);
        cb3.setChecked(false);
        cb4.setChecked(false);
        cb5.setChecked(false);
        cb6.setChecked(false);
        cb7.setChecked(false);
        cb8.setChecked(false);
        cb9.setChecked(false);
        cb10.setChecked(false);
        cb11.setChecked(false);
        cb12.setChecked(false);
        cb13.setChecked(false);
        cb14.setChecked(false);

        txtv1.setText(" 1");
        txtv2.setText(" 1");
        txtv3.setText(" 1");
        txtv4.setText(" 1");
        txtv5.setText(" 1");
        txtv6.setText(" 1");
        txtv7.setText(" 1");
        txtv8.setText(" 1");
        txtv9.setText(" 1");
        txtv10.setText(" 1");
        txtv11.setText(" 1");
        txtv12.setText(" 1");
        txtv13.setText(" 1");

        coffeeType1 ="";
        coffeeType2 ="";
        coffeeType3 ="";
        coffeeType4 ="";
        coffeeType5 ="";
        coffeeType6 ="";
        coffeeType7 ="";
        coffeeType8 ="";
        coffeeType9 ="";
        coffeeType10 ="";
        sweetType1 ="";
        sweetType2 ="";
        sweetType3 ="";
        sweetType4 ="";

        tx1.setText("  10 SR");
        tx2.setText("  8 SR");
        tx3.setText("  12 SR");
        tx4.setText("  10 SR");
        tx5.setText("  7 SR");
        tx6.setText("  12 SR");
        tx7.setText("  12 SR");
        tx8.setText("  10 SR");
        tx9.setText("  10 SR");
        tx10.setText("  14 SR");
        tx11.setText("  5 SR");
        tx12.setText("  6 SR");
        tx13.setText("  4 SR");
        tx14.setText("  4 SR");

        numCofe1 = 1;
        numCofe2 = 1;
        numCofe3 = 1;
        numCofe4 = 1;
        numCofe5 = 1;
        numCofe6 = 1;
        numCofe7 = 1;
        numCofe8 = 1;
        numCofe9 = 1;
        numCofe10 = 1;
        numSwet1 = 1;
        numSwet2 = 1;
        numSwet3 = 1;
        numSWet4 = 1;




    }
}