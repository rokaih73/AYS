package com.example.aystest;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HOMEActivity extends AppCompatActivity {
    private TabLayout tab1;
    private AppBarLayout bar1;
    private ViewPager vp1;
    String b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        tab1 = (TabLayout) findViewById(R.id.t1);//this is the id of TabLayout from mainActivity axl file
        //bar1 = (AppBarLayout) findViewById(R.id.bb1);
        vp1 = (ViewPager) findViewById(R.id.p1);
        //this code is for adding fragment
        ViewPageAdapter adapter = new ViewPageAdapter(getSupportFragmentManager());
        adapter.AddFragment(new fragmentMakeOrder(), "Make Order");
        adapter.AddFragment(new fragmentMyAccount(), "My Account");
        adapter.AddFragment(new fragmentMyCart(), "About US");

        //adapter setup
        vp1.setAdapter(adapter);
        tab1.setupWithViewPager(vp1);
//________________________________________
    }
}
